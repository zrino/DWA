<!DOCTYPE html>
<html>
<head>
	<title> Tablica </title>
	<link rel="stylesheet" type="text/css" href="mystyle.css">
	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">

	<!-- jQuery library -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
	<meta charset="utf8"> 
	<!-- Latest compiled JavaScript -->
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<main>
	<div id="content">
	Unesite pojam za pretraživanje<input onkeyup="pretrazi()" type="text" name="query" id="query">
	
<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "root";
$db = "FantasticBeasts_proizvodi";

// Create connection
$conn = new mysqli($servername, $username, $password,$db);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$conn->set_charset("utf8");
$sql = "SELECT * FROM Proizvodi";
$result = $conn->query($sql);
$cnt = 1;
if ($result->num_rows > 0) 
{
	echo '<table id="tablica" border="1" style="width:100%">
		<tr> 	<th>Naziv </th>
			<th> Opis </th>
			<th> Cijena </th>
		</tr>';
	
	while($row = $result->fetch_assoc()) 
	{
		echo '	<tr>
			<td>' . $row["Naziv"] . '</td>
			<td>' . $row["Opis"] . '</td>
			<td>' . $row["Cijena"] . 'kn </td>
			<td> <button type="button" onclick=dodajCookie(' . $row["PID"] . ')> Dodaj u košaricu </td>
			</tr>';
		$cnt+=1;
	}
	echo ' 	<tr>
				<td colspan="4">
				<button id="obrisi" type="button" onclick="obrisi()"> Obriši sve iz košarice  </button>
				</td>
			</tr>';
	echo '</table>'; 
}
else
{
	echo '0 results';
}

?><form action ="kupovina.php" method="POST">
	
	<input type="submit" value="Proslijedi na blagajnu">
	</form>
	</div>
	<div id="footer">
	Copyright Fantastic Beasts 2016
	</div>
</main>

</body>
<footer>
	<script>
		
		function pretrazi()
		{
			var str = document.getElementById("query").value;
			var table = document.getElementById("tablica");
			if(str) //ako je value određen filtriraj
			{
				for(var i = 0; i < table.rows.length; i++)
				{
					
					for(var j = 0; j < table.rows[i].cells.length; j++)
					{
						
						if (table.rows[i].cells[j].textContent.search(str) == -1 && i > 0)
						{
						
							table.rows[i].cells[j].style="visibility:hidden";
						}
						else
						{
							table.rows[i].cells[j].style="visibility:visible";
						}
					}
				}
			}
			else //ako je box prazan, prikaži sve rezultate ponovno
			{
				for(var i = 0; i < table.rows.length; i++)
				{
					for(var j = 0; j < table.rows[i].cells.length; j++)
					{
							table.rows[i].cells[j].style="visibility:visible";
						
					}
				}
			}		
		}
		function getCookie(cname) 
		{
			var name = cname + "=";
			var ca = document.cookie.split(';');
			for(var i=0; i<ca.length; i++) {
				var c = ca[i];
				while (c.charAt(0)==' ') c = c.substring(1);
				if (c.indexOf(name) == 0) return c.substring(name.length, c.length);
			}
			return "";
		}
		function dodajCookie(x)
		{
			var days = 7;
			var name="košarica=";
			var d = new Date();
			d.setTime(d.getTime() + (days*24*60*60*1000));
			var kosarica=getCookie("košarica");
			if(kosarica!="")
			{
				var oldCookie = getCookie("košarica");
				var newCookie = oldCookie + "#proizvod" + x;
				setCookie("košarica",newCookie);
			}
			else
				setCookie("košarica",name+"#proizvod"+x);
			
			
			
			alert(getCookie("košarica"));
		}
		function obrisi()
		{
			document.cookie = "košarica=; expires=Thu, 01 Jan 1970 00:00:00 UTC"; 
			alert(getCookie("košarica"));
		}
		function setCookie(cname, cvalue)
		{
			var d = new Date();
			d.setTime(d.getTime() + (7*24*60*60*1000));
			var expires = "expires="+d.toUTCString();
			document.cookie = cname + "=" + cvalue + "; " + expires;
		}

	</script>
</footer>
