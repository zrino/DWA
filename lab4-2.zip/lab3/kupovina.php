<?php
session_start();
$cookie_name = "košarica";
$arr = array();
$i = 0;
$string = $_COOKIE[$cookie_name]; 
$proizvodi = substr($string,strlen($cookie_name)+1);
$token = strtok($proizvodi, "#");
while ($token !== false)// tokenizacija
{
	echo "$token<br>";
	$token = strtok("#");
	$arr[$i] = $token;
} 
$servername = "localhost";
$username = "root";
$password = "root";
$db = "FantasticBeasts_proizvodi";

// Create connection
$conn = new mysqli($servername, $username, $password,$db);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$conn->set_charset("utf8");
for($j = 0; $j < count($arr); $j++)
{
	$sql = "SELECT * FROM Proizvodi WHERE PID=" . substr($arr[$j],strlen("proizvod"));
	$result = $conn->query($sql);
	$cnt = 1;
		if ($result->num_rows > 0) 
		{
			while($row = $result->fetch_assoc()) 
			{
				echo '
					<p>' . $row["Naziv"] . '</p>
					<p>' . $row["Opis"] . '</p>
					<p>' . $row["Cijena"] . 'kn </p>
					</br>
					';
				$cnt+=1;
			}
			
		}
		else
		{
			echo '0 results';
		}
}




?>