<!DOCTYPE html>
<html>
<head>
	<title> Forma </title>
	<link rel="stylesheet" type="text/css" href="mystyle.css">
	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">

	<!-- jQuery library -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
	<meta charset="utf8"> 
	<!-- Latest compiled JavaScript -->
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<main>
	<div id="zivotopis">
		<div id="Osobni podaci">
		<h3 onmouseover="sakrij(this)"> Osobni podaci </h3>
			<p> Zrino Pernar </p>
			<p> Vladimira Ruždjaka 33 Grad Zagreb </p>
			<p> 24.07.1994 </p>
		</div>
		<div id="skolovanje">
			<h3 onmouseover="sakrij(this)"> Obrazovanje </h3>
			<p> Osnovna škola Jure Kaštelana</p>
			<p> XIII. gimnazija </p>
			<p> TVZ</p>
		</div>
		<div id="znanja">
			
			<h3 onmouseover="sakrij(this)"> Znanja i vještine </h3>
			<p> HTML,CSS, Javascript, PHP, C#, C </p>
			
		</div>
	</div>
	<div id="footer">
	Copyright Fantastic Beasts 2016
	</div>
</main>

</body>
<footer>

	<script>
		function sakrij(x)
		{
			x.style="visibility:hidden";
			
			
		}
	</script>
</footer>